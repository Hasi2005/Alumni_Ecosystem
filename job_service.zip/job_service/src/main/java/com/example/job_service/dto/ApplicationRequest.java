package com.example.job_service.dto;

public class ApplicationRequest {
    private Long jobId;

    public Long getJobId() { return jobId; }
    public void setJobId(Long jobId) { this.jobId = jobId; }
}
