package com.example.job_service.model;

public enum Outcome {
    APPLIED,
    REFERRED,
    SHORTLISTED,
    INTERVIEWED,
    OFFERED,
    REJECTED,
    JOINED
}
