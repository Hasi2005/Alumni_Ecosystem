package com.example.job_service.service;

import com.example.job_service.model.Application;
import com.example.job_service.model.Outcome;
import com.example.job_service.repository.ApplicationRepository;
import com.example.job_service.dto.ApplicationRequest;
import com.example.job_service.dto.ApplicationResponse;

import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ApplicationService {

    @Autowired
    private ApplicationRepository applicationRepository;

    // Get all applications (used internally if needed)
    public List<ApplicationResponse> getAllApplications() {
        return applicationRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    // Get applications for a specific student
    public List<ApplicationResponse> getApplicationsByStudentUsername(String studentUsername) {
        return applicationRepository.findByStudentUsername(studentUsername).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    // Apply for a job (student)
    public ApplicationResponse applyForJob(ApplicationRequest request, String studentUsername) {
        // Generate dummy ID for new application (optional if DB auto-generates)
        Long appId = new Random().nextLong();

        Application application = new Application(
                appId,
                request.getJobId(),
                studentUsername,
                Outcome.APPLIED
        );

        Application savedApp = applicationRepository.save(application);
        return mapToResponse(savedApp);
    }

    // Update application status (admin)
    public ApplicationResponse updateStatus(Long id, Outcome status) {
        Application app = applicationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Application not found"));

        app.setStatus(status);  // make sure Application entity has setStatus()
        Application updatedApp = applicationRepository.save(app);
        return mapToResponse(updatedApp);
    }

    // Mapper from Application model → ApplicationResponse DTO
    private ApplicationResponse mapToResponse(Application app) {
        return new ApplicationResponse(
                app.getId(),
                app.getJobId(),
                app.getStudentUsername(),
                app.getStatus()
        );
    }
}
