package com.example.job_service.service;

import com.example.job_service.model.Job;
import com.example.job_service.repository.JobRepository;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

@Service
public class JobService {

    @Autowired
    private JobRepository jobRepository;

    public List<Job> getAllJobs() {
        return jobRepository.findAll();
    }

    public Job getJobById(Long id) {
        return jobRepository.findById(id).orElse(null);
    }

    public Job createJob(Job job, String alumniUsername) {
        Job newJob = new Job(job.getId(), alumniUsername, job.getTitle(), job.getDescription(), job.getType(), job.getLocation());
        return jobRepository.save(newJob);
    }

    public List<Job> getJobsByAlumniUsername(String alumniUsername) {
        return jobRepository.findByAlumniUsername(alumniUsername);
    }
}
