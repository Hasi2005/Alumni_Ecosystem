(function () {
  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => Array.from(document.querySelectorAll(sel));

  // Tabs
  $$(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const tab = btn.getAttribute("data-tab");
      $$(".tab-btn").forEach((b) => b.setAttribute("aria-selected", String(b === btn)));
      $$(".tab").forEach((s) => s.classList.toggle("active", s.id === `tab-${tab}`));
    });
  });

  function setText(el, text) {
    if (!el) return;
    el.textContent = text;
  }

  function setHTML(el, html) {
    if (!el) return;
    el.innerHTML = html;
  }

  async function doFetch(path, opts = {}) {
    const options = {
      method: opts.method || "GET",
      credentials: "include",
      headers: Object.assign({}, opts.headers || {}),
    };
    if (opts.body) {
      options.headers["Content-Type"] = "application/json";
      options.body = JSON.stringify(opts.body);
    }
    try {
      const res = await fetch(path, options);
      let payload = null;
      try { payload = await res.json(); } catch { payload = await res.text(); }
      if (!res.ok) {
        throw new Error(`${res.status} ${res.statusText}: ${typeof payload === 'string' ? payload : JSON.stringify(payload)}`);
      }
      return payload;
    } catch (err) {
      throw err;
    }
  }

  // Rendering helpers
  function renderJob(job) {
    return `<div class="item">
      <div><strong>${escapeHtml(job.title)}</strong> <span class="pill">${escapeHtml(job.type)}</span></div>
      <div>${escapeHtml(job.location || "")}</div>
      <details><summary>Description</summary><pre>${escapeHtml(job.description || "")}</pre></details>
      <small>ID: ${job.id}</small>
    </div>`;
  }

  function renderApplication(app) {
    return `<div class="item">
      <div>Application <strong>#${app.id}</strong> for Job <strong>#${app.jobId}</strong></div>
      <div>Student: ${escapeHtml(app.studentUsername || "-")}</div>
      <div>Status: <span class="pill">${escapeHtml(app.status || "-")}</span></div>
    </div>`;
  }

  function renderReferral(ref) {
    return `<div class="item">
      <div>Referral <strong>#${ref.id}</strong> for Job <strong>#${ref.jobId}</strong></div>
      <div>Student: ${escapeHtml(ref.studentUsername || "-")}</div>
      <div>Alumni: ${escapeHtml(ref.alumniUsername || "-")}</div>
      <div>Status: <span class="pill">${escapeHtml(ref.status || "-")}</span></div>
    </div>`;
  }

  function escapeHtml(s) {
    return String(s)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  // Jobs
  $("#btn-load-jobs").addEventListener("click", async () => {
    const alumni = $("#jobs-alumni-filter").value.trim();
    const url = alumni ? `/api/jobs?alumniUsername=${encodeURIComponent(alumni)}` : "/api/jobs";
    setHTML($("#jobs-list"), "Loading...");
    try {
      const list = await doFetch(url);
      if (!Array.isArray(list)) throw new Error("Unexpected response");
      setHTML($("#jobs-list"), list.map(renderJob).join("") || "<em>No jobs</em>");
    } catch (e) {
      setHTML($("#jobs-list"), `<pre class="error">${escapeHtml(e.message)}</pre>`);
    }
  });

  $("#btn-load-job-by-id").addEventListener("click", async () => {
    const id = Number($("#job-by-id").value);
    if (!id) { setText($("#job-detail"), "Enter a job ID"); return; }
    setHTML($("#job-detail"), "Loading...");
    try {
      const job = await doFetch(`/api/jobs/${id}`);
      setHTML($("#job-detail"), renderJob(job));
    } catch (e) {
      setHTML($("#job-detail"), `<pre class="error">${escapeHtml(e.message)}</pre>`);
    }
  });

  $("#btn-create-job").addEventListener("click", async () => {
    const title = $("#job-title").value.trim();
    const description = $("#job-description").value.trim();
    const type = $("#job-type").value;
    const location = $("#job-location").value.trim();
    const out = $("#create-job-result");
    setText(out, "Submitting...");
    try {
      const result = await doFetch("/api/jobs", { method: "POST", body: { title, description, type, location } });
      setText(out, JSON.stringify(result, null, 2));
    } catch (e) {
      setText(out, e.message);
      out.classList.add("error");
    }
  });

  // Applications
  $("#btn-my-applications").addEventListener("click", async () => {
    const el = $("#applications-list");
    setHTML(el, "Loading...");
    try {
      const list = await doFetch("/api/applications/me");
      if (!Array.isArray(list)) throw new Error("Unexpected response");
      setHTML(el, list.map(renderApplication).join("") || "<em>No applications</em>");
    } catch (e) {
      setHTML(el, `<pre class="error">${escapeHtml(e.message)}</pre>`);
    }
  });

  $("#btn-all-applications").addEventListener("click", async () => {
    const el = $("#applications-list");
    setHTML(el, "Loading...");
    try {
      const list = await doFetch("/api/applications");
      if (!Array.isArray(list)) throw new Error("Unexpected response");
      setHTML(el, list.map(renderApplication).join("") || "<em>No applications</em>");
    } catch (e) {
      setHTML(el, `<pre class="error">${escapeHtml(e.message)}</pre>`);
    }
  });

  $("#btn-apply").addEventListener("click", async () => {
    const jobId = Number($("#apply-job-id").value);
    const out = $("#apply-result");
    if (!jobId) { setText(out, "Enter a job ID"); return; }
    setText(out, "Submitting...");
    try {
      const result = await doFetch("/api/applications", { method: "POST", body: { jobId } });
      setText(out, JSON.stringify(result, null, 2));
    } catch (e) {
      setText(out, e.message);
      out.classList.add("error");
    }
  });

  $("#btn-update-application").addEventListener("click", async () => {
    const id = Number($("#app-update-id").value);
    const status = $("#app-update-status").value;
    const out = $("#app-update-result");
    if (!id) { setText(out, "Enter application ID"); return; }
    setText(out, "Updating...");
    try {
      const result = await doFetch(`/api/applications/${id}/status`, { method: "PUT", body: { status } });
      setText(out, JSON.stringify(result, null, 2));
    } catch (e) {
      setText(out, e.message);
      out.classList.add("error");
    }
  });

  // Referrals
  $("#btn-my-referrals-student").addEventListener("click", async () => {
    const el = $("#referrals-list");
    setHTML(el, "Loading...");
    try {
      const list = await doFetch("/api/referrals/student/me");
      if (!Array.isArray(list)) throw new Error("Unexpected response");
      setHTML(el, list.map(renderReferral).join("") || "<em>No referrals</em>");
    } catch (e) {
      setHTML(el, `<pre class="error">${escapeHtml(e.message)}</pre>`);
    }
  });

  $("#btn-my-referrals-alumni").addEventListener("click", async () => {
    const el = $("#referrals-list");
    setHTML(el, "Loading...");
    try {
      const list = await doFetch("/api/referrals/alumni/me");
      if (!Array.isArray(list)) throw new Error("Unexpected response");
      setHTML(el, list.map(renderReferral).join("") || "<em>No referrals</em>");
    } catch (e) {
      setHTML(el, `<pre class="error">${escapeHtml(e.message)}</pre>`);
    }
  });

  $("#btn-all-referrals").addEventListener("click", async () => {
    const el = $("#referrals-list");
    setHTML(el, "Loading...");
    try {
      const list = await doFetch("/api/referrals");
      if (!Array.isArray(list)) throw new Error("Unexpected response");
      setHTML(el, list.map(renderReferral).join("") || "<em>No referrals</em>");
    } catch (e) {
      setHTML(el, `<pre class="error">${escapeHtml(e.message)}</pre>`);
    }
  });

  $("#btn-request-referral").addEventListener("click", async () => {
    const jobId = Number($("#ref-job-id").value);
    const alumniUsername = $("#ref-alumni-username").value.trim();
    const out = $("#ref-request-result");
    if (!jobId || !alumniUsername) { setText(out, "Enter job ID and alumni username"); return; }
    setText(out, "Submitting...");
    try {
      const result = await doFetch("/api/referrals/request", { method: "POST", body: { jobId, alumniUsername } });
      setText(out, JSON.stringify(result, null, 2));
    } catch (e) {
      setText(out, e.message);
      out.classList.add("error");
    }
  });

  $("#btn-update-referral").addEventListener("click", async () => {
    const id = Number($("#ref-update-id").value);
    const status = $("#ref-update-status").value;
    const out = $("#ref-update-result");
    if (!id) { setText(out, "Enter referral ID"); return; }
    setText(out, "Updating...");
    try {
      const result = await doFetch(`/api/referrals/${id}/status`, { method: "PUT", body: { status } });
      setText(out, JSON.stringify(result, null, 2));
    } catch (e) {
      setText(out, e.message);
      out.classList.add("error");
    }
  });

  // Initial convenience: preload jobs list
  const preloadBtn = $("#btn-load-jobs");
  if (preloadBtn) preloadBtn.click();
})();

